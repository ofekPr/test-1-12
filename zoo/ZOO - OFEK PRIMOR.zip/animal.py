class Animal:
    def __init__(self, name, age, isSuperPredator, calPerMeal):
        self.name = name
        self.age = age
        self.isSuperPredator = isSuperPredator
        self.calPerMeal = calPerMeal

    def __str__(self):
        return self.name + " is " + str(self.age) + " years old. Is super-predator? " + str(
            self.isSuperPredator) + ". And eats " + str(self.calPerMeal) + " calories per meal.\n"

    def eat(self):
        return self.calPerMeal * 3
